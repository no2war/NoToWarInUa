/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.41505522227368, "KoPercent": 0.5849447777263211};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9893041125804239, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.999833431513945, 500, 1500, "getApprovalRole"], "isController": false}, {"data": [0.9999959371724345, 500, 1500, "RemoveExcess"], "isController": false}, {"data": [0.9995027257372302, 500, 1500, "loginRequest"], "isController": false}, {"data": [1.0, 500, 1500, "GetCardID"], "isController": false}, {"data": [0.9956067839803868, 500, 1500, "getRequest"], "isController": false}, {"data": [0.9983736703656367, 500, 1500, "logoutRequest"], "isController": false}, {"data": [0.9961685823754789, 500, 1500, "searchCard"], "isController": false}, {"data": [0.9959699086512628, 500, 1500, "AcquaintanceRequest"], "isController": false}, {"data": [1.0, 500, 1500, "FillFields"], "isController": false}, {"data": [0.9980215958855694, 500, 1500, "newRequest"], "isController": false}, {"data": [0.8741797866937532, 500, 1500, "StartProcessStoreRequest"], "isController": false}, {"data": [1.0, 500, 1500, "FillRoles"], "isController": false}, {"data": [0.9964726631393298, 500, 1500, "reportBuild"], "isController": false}, {"data": [0.9159255542599913, 500, 1500, "storeRequest"], "isController": false}, {"data": [1.0, 500, 1500, "GetRandomParam"], "isController": false}, {"data": [0.999964451688626, 500, 1500, "getAddressesRole"], "isController": false}, {"data": [0.9731327243417518, 500, 1500, "getTask"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 5059281, 29594, 0.5849447777263211, 49.51210300436305, 0, 21623, 150.90000000000146, 224.0, 657.9900000000016, 116.79023413629335, 398.436716755079, 2494.8812482004664], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["getApprovalRole", 492290, 0, 0.0, 17.529328241483373, 11, 10391, 23.0, 40.0, 77.0, 11.398984078192461, 48.6080736781894, 44.79453239266398], "isController": false}, {"data": ["RemoveExcess", 246134, 1, 4.062827565472466E-4, 0.36879910942819977, 0, 67, 1.0, 1.0, 1.0, 5.70048362883282, 0.0, 0.0], "isController": false}, {"data": ["loginRequest", 296617, 0, 0.0, 48.091667031896364, 28, 7798, 79.0, 95.0, 152.0, 6.847211862477084, 22.301789634462484, 4.358034548005404], "isController": false}, {"data": ["GetCardID", 1861, 0, 0.0, 0.14830736163353045, 0, 14, 1.0, 1.0, 1.0, 0.04309990945776678, 0.0, 0.0], "isController": false}, {"data": ["getRequest", 247996, 0, 0.0, 93.01150018548705, 46, 10483, 110.0, 150.0, 458.9900000000016, 5.742285895938052, 57.33862859666093, 21.724199349700527], "isController": false}, {"data": ["logoutRequest", 295758, 0, 0.0, 24.6146308806528, 6, 12769, 27.0, 58.95000000000073, 117.9900000000016, 6.832194183840536, 11.919703315805735, 24.141143636067003], "isController": false}, {"data": ["searchCard", 2871, 0, 0.0, 42.27412051549995, 17, 2623, 43.0, 71.0, 475.5600000000004, 0.06665745705632219, 0.03637428022106548, 0.32726352172984347], "isController": false}, {"data": ["AcquaintanceRequest", 1861, 0, 0.0, 94.70284793121965, 33, 3557, 139.0, 207.89999999999986, 431.3799999999999, 0.043097035905828834, 0.010724121004284137, 0.20499349789247157], "isController": false}, {"data": ["FillFields", 246143, 0, 0.0, 0.9449344486741387, 0, 247, 1.0, 1.0, 2.0, 5.700112919402974, 0.0, 0.0], "isController": false}, {"data": ["newRequest", 246158, 0, 0.0, 49.55832839070821, 17, 14987, 124.0, 187.0, 407.0, 5.699079666168649, 30.695657972685613, 22.10619808773672], "isController": false}, {"data": ["StartProcessStoreRequest", 246125, 29593, 12.023565261554088, 179.41947384459195, 47, 12644, 232.0, 405.0, 757.0, 5.7004567197817595, 5.578485985800623, 36.558052747181534], "isController": false}, {"data": ["FillRoles", 18610, 0, 0.0, 0.0910263299301452, 0, 18, 0.0, 1.0, 1.0, 0.43099346494868646, 0.0, 0.0], "isController": false}, {"data": ["reportBuild", 2268, 0, 0.0, 238.06657848324548, 113, 3712, 275.0, 339.0, 449.30999999999995, 0.052621006389276005, 0.09151207085399948, 0.2176244237239951], "isController": false}, {"data": ["storeRequest", 246139, 0, 0.0, 402.88033184501467, 111, 21623, 756.0, 1118.0, 1869.9800000000032, 5.70027307878896, 3.1325132658927775, 2124.2339166467837], "isController": false}, {"data": ["GetRandomParam", 5150, 0, 0.0, 0.22718446601941797, 0, 17, 1.0, 1.0, 1.0, 0.11923726031487389, 0.0, 0.0], "isController": false}, {"data": ["getAddressesRole", 2461439, 0, 0.0, 16.36197281346481, 10, 11124, 22.0, 35.0, 79.0, 57.00103401025562, 219.5891754807481, 223.99695703107838], "isController": false}, {"data": ["getTask", 1861, 0, 0.0, 157.69102632993005, 76, 3989, 176.79999999999995, 487.99999999999864, 1348.8399999999979, 0.04309926165244468, 0.27967934810815087, 0.16069504921143637], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400\/Bad Request", 29593, 99.99662093667635, 0.5849250120718734], "isController": false}, {"data": ["500\/javax.script.ScriptException: java.lang.IllegalArgumentException: Text must not be null or empty", 1, 0.0033790633236466853, 1.9765654447736744E-5], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 5059281, 29594, "400\/Bad Request", 29593, "500\/javax.script.ScriptException: java.lang.IllegalArgumentException: Text must not be null or empty", 1, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["RemoveExcess", 246134, 1, "500\/javax.script.ScriptException: java.lang.IllegalArgumentException: Text must not be null or empty", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["StartProcessStoreRequest", 246125, 29593, "400\/Bad Request", 29593, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
